### Story 1

_long and romantic_

Once upon a time a young knight Killy became a happy owner of the Old Castle of Underworld which abandoned for as long as one hundred years. Those who stepped to this cursed ground was unable to return. The great King Mutabor owned these lands. Making this gift to his bravest knight was a plan to eliminate him so Killy could never meet the princess fallen in love with him. Killy is accepting his fate and promising to clean the castle from all the cursed souls and danger.
Killy is moving alone in a narrow dark labyrinth full of unseen creatures of the Underworld. And at the darkest moment when he almost left his hope, he sees the tree growing through the dungeon ceiling straight to the sky. The tree is imprisoned in a huge metal chain. Killy chops the chain and the Tree starts speaking to him promising to fulfil one wish.
Killy wishes to have a pair of wings. The wings start to grow from his back immediately and he flies away from the dungeon through the hole in the ceiling.

### Story 2.0

_less long, less romantic_

Once the young knight Killy became the proud owner of the Old Castle of the Underworld, abandoned for a hundred years.
Those who set foot on this cursed land could not return.
But Killy didn't know about it. He arrived from a distant country after receiving a letter from his uncle, who was the lord of the country and had died very recently. No one in the family heard anything from the uncle for ages. No one was even sure that the uncle really existed.
Striving to become rich Killy accepts the offer and falls straight into a death trap.

### Story 2.1

_shorter less personalized version_

Once upon a time the young knight receives a mystique letter from his far relative that claims him to be a new owner of the the Old Castle of the Underworld.
The castle was abandoned for a hundred years.
But the knight doesn't know about it.
Striving to become rich he accepts the offer and falls straight into a death trap of the cursed dungeon.

### Story 3 
**Cleaning company**

The Cleaning Company can clean not only blood from your floor and ceiling. Any abandoned dungeons could be cleaned with our great service and passion. The price is all the artefacts that could be hidden in the property.